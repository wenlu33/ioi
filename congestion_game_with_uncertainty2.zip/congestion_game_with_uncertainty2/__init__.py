from otree.api import *
import random

doc = """
Game with Guess → Choose → Group Result (Part 2 for BI and BT Treatments)
"""

class C(BaseConstants):
    NAME_IN_URL = 'congestion_game_with_uncertainty2'
    PLAYERS_PER_GROUP = 5
    NUM_ROUNDS = 10  # 10 rounds total for each treatment

class Subsession(BaseSubsession):
    def creating_session(subsession):
        for group in subsession.get_groups():
            # Ensure that box_a_color is assigned before usage
            group.box_a_color = random.choice(['YELLOW', 'BLUE'])  # Assign color for Box A

            # Handle treatment logic for each player
            for player in subsession.get_players():
                player.participant.treatment = player.participant.vars.get('treatment', 'BB')  # Default to 'BB' if treatment not set

class Group(BaseGroup):
    box_a_color = models.StringField()  # YELLOW or BLUE
    box_b_size = models.StringField()   # Small or Large
    box_b_earnings = models.FloatField()

class Player(BasePlayer):
    first_guess = models.IntegerField(label="Your guess about Yellow ball", min=0, max=100)
    choice = models.StringField(
        choices=[['A', 'Choose Box A'], ['B', 'Choose Box B']],
        widget=widgets.RadioSelect
    )
    round_payoff = models.FloatField()  # Renamed 'payoff' to 'round_payoff'
    second_guess = models.IntegerField(min=0, max=100, blank=True)  # For BI treatment only

# ----------------- Pages -----------------

class GuessPage1(Page):
    form_model = 'player'
    form_fields = ['first_guess']

class Choice(Page):
    form_model = 'player'
    form_fields = ['choice']

# -------------- For BI and BT treatment pages ----------------
# This page only appears for BI treatment to show the Clue Ball.
class ClueBallPage(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.participant.treatment == 'BI'  # Only for BI treatment

    @staticmethod
    def vars_for_template(player: Player):
        # Provide the color of Box A to the template (so it can show the appropriate Clue Ball)
        box_a_color = player.group.box_a_color if player.group.box_a_color is not None else "Unknown"
        return {
            "box_a_color": box_a_color  # Show the color of Box A
        }

# This page handles the second guess for BI treatment after the Clue Ball is shown
class SecondGuessPage(Page):
    form_model = 'player'
    form_fields = ['second_guess']

    @staticmethod
    def is_displayed(player: Player):
        return player.participant.treatment == 'BI'  # Only for BI treatment

    @staticmethod
    def vars_for_template(player: Player):
        return {
            "box_a_color": player.group.box_a_color  # Show the color of Box A
        }

class ResultsWaitPage(WaitPage):
    @staticmethod
    def after_all_players_arrive(group: Group):
        players = group.get_players()
        num_box_b = sum(1 for p in players if p.choice == 'B')

        # Part 2: Different logic based on treatment
        if group.session.config['treatment'] == 'BT':  # For BT treatment
            # Modified payoff structure for Box B in Part 2
            modified_payoff_table = {0: 2.5, 1: 2, 2: 1.5, 3: 1, 4: 0.5, 5: 0}
            group.box_b_earnings = modified_payoff_table.get(num_box_b, 0)
        else:
            # Standard payoff structure for Box B for BI and BB treatments
            payoff_table = {0: 3, 1: 2.5, 2: 2, 3: 1.5, 4: 1, 5: 0.5}
            group.box_b_earnings = payoff_table.get(num_box_b, 0)

        # Assign payoff to players based on choice
        for p in players:
            if p.choice == 'A':
                if group.box_a_color == 'YELLOW':
                    p.round_payoff = 3  # Renamed from 'payoff' to 'round_payoff'
                else:
                    p.round_payoff = 1  # Renamed from 'payoff' to 'round_payoff'
            else:
                p.round_payoff = group.box_b_earnings  # Renamed from 'payoff' to 'round_payoff'

class ResultsPage(Page):
    @staticmethod
    def vars_for_template(player: Player):
        group = player.group
        players = group.get_players()
        num_box_b = sum(1 for p in players if p.choice == 'B')

        return dict(
            round_number=player.round_number,
            first_guess=player.first_guess,
            choice=player.choice,
            box_a_color=group.box_a_color,
            box_b_size=group.box_b_size,
            num_box_b=num_box_b,
            round_earnings=player.round_payoff  # Renamed from 'payoff' to 'round_payoff'
        )

# ----------------- Page Sequence -----------------
page_sequence = [GuessPage1, Choice, ClueBallPage, SecondGuessPage, ResultsWaitPage, ResultsPage]